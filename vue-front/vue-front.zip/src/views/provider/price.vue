<template>

		<section class="pt-120 pb-90">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-lg-4 col-md-6">
						<div class="price style--two">
							<div class="price-head">
								<h3>Staring Repair</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 96 <span>(No Fix No Fees)</span></span>
							</div>
							<div class="price-body">
								<ul>
									<li><span>Display Repair</span> <span>$12</span></li>
									<li><span>Hardware Upgrade</span> <span>$34</span></li>
									<li><span>Software Installation</span> <span>$17</span></li>
									<li><span>SWindows Insllation</span> <span>$49</span></li>
									<li><span>Data Recovery</span> <span>$21</span></li>
									<li><span>Windows Activation</span> <span>$30</span></li>
								</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="price style--two active">
							<div class="price-head">
								<h3>Body Painting</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 69 <span>(No Fix No Fees)</span></span>
							</div>
							<div class="price-body">
								<ul>
									<li><span>Display Repair</span> <span>$12</span></li>
									<li><span>Hardware Upgrade</span> <span>$34</span></li>
									<li><span>Software Installation</span> <span>$17</span></li>
									<li><span>SWindows Insllation</span> <span>$49</span></li>
									<li><span>Data Recovery</span> <span>$21</span></li>
									<li><span>Windows Activation</span> <span>$30</span></li>
								</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-6">
						<div class="price style--two">
							<div class="price-head">
								<h3>Engine Repair</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 36 <span>(No Fix No Fees)</span></span>
							</div>
							<div class="price-body">
								<ul>
									<li><span>Sound System Repair</span> <span>$50</span></li>
									<li><span>Display Repair</span> <span>$34</span></li>
									<li><span>Water Clean</span> <span>$35</span></li>
									<li><span>Camera Services</span> <span>$49</span></li>
									<li><span>Power Button Repair</span> <span>$25</span></li>
									<li><span>Headphone Repair</span> <span>$30</span></li>
								</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        
		<div class="pt-120 pb-90">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-auto">
						<div class="section-title text-center">
							<h5 class="top-title icon-center">Reserve Partner</h5>
							<h2>Our Partners</h2>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/07.png" alt=""></div>
					</div>
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/08.png" alt=""></div>
					</div>
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/09.png" alt=""></div>
					</div>
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/10.png" alt=""></div>
					</div>
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/11.png" alt=""></div>
					</div>
					<div class="col-lg-2 col-sm-4 col-6">
						<div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/12.png" alt=""></div>
					</div>
				</div>
			</div>
		</div>

</template>

