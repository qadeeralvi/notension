<template>
   
    <section class="pt-120 bg-center" :style="{ backgroundImage: 'url(' + aboutBg + ')' }">

       <div class="container">
          <div class="row mb-70">
             <div class="col-lg-6">
                <div class="about-content mb-5 mb-lg-0">
                   <h5 class="top-title">About us</h5>
                   <h2>Innovative Solution </h2>
                </div>
             </div>
             <div class="col-lg-6">
                <div class="about-right-content">
                   <p>Involve content generation consumption screen space dedicated content over other elements To ensure there is enough space.Our first project, Notension, was founded in 2010 by brothers Alu baba and Polow baba, along with their friend Joaquín hadda haddi, founder of Gondhor acquired by car servicing company.</p>
                   <p>Alu baba felt the urge to create a platform where designers could find free graphic resource bablo and aquín supported his idea and thats how Notension company was created. since then our universe has been expanding non-stop, creating two new project.</p>
                   <div class="arrow-box"><img src="http://127.0.0.1:5173/assets/img/icon/about-arrow.svg" alt="" class="svg"></div>
                </div>
             </div>
          </div>
          <div class="row justify-content-end">
             <div class="col-lg-8">
                <div class="statistics-wrapper" data-bg-img="assets/img/bg/about_bg.png">
                   <div class="statistics d-flex flex-column flex-sm-row justify-content-evenly">
                      <div class="statistic mb-5 mb-sm-0">
                         <h3>29+</h3>
                         <h4>Experience</h4>
                      </div>
                      <div class="statistic mb-5 mb-sm-0">
                         <h3>99k+</h3>
                         <h4>Happy Client</h4>
                      </div>
                      <div class="statistic">
                         <h3>120k+</h3>
                         <h4>Servicing</h4>
                      </div>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <section class="pt-190 pb-90 section-bg">
       <div class="container">
          <div class="row justify-content-center">
             <div class="col-lg-4 col-md-6">
                <div class="mission">
                   <div class="mission-thumb"><img src="http://127.0.0.1:5173/assets/img/media/mission1.png" data-rjs="2" alt=""></div>
                   <div class="mission-content">
                      <h3 class="post-title">Notension History</h3>
                      <p>Located in the 27604 area of Raleigh, NC, USA home our famous 3 year / 36,000 mile warranty. certified technicians support.</p>
                      <a href="blog-details.html" class="btn btn-border sm c1-hover"><span>Read More</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
                   </div>
                </div>
             </div>
             <div class="col-lg-4 col-md-6">
                <div class="mission">
                   <div class="mission-thumb"><img src="http://127.0.0.1:5173/assets/img/media/mission2.png" data-rjs="2" alt=""></div>
                   <div class="mission-content">
                      <h3 class="post-title">Notension Mission</h3>
                      <p>Our complete auto repair facility services import domestic cars, performing auto repair & service from brake state inspections.</p>
                      <a href="blog-details.html" class="btn btn-border sm c1-hover"><span>Read More</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
                   </div>
                </div>
             </div>
             <div class="col-lg-4 col-md-6">
                <div class="mission">
                   <div class="mission-thumb"><img src="http://127.0.0.1:5173/assets/img/media/mission3.png" data-rjs="2" alt=""></div>
                   <div class="mission-content">
                      <h3 class="post-title">Notension Vision</h3>
                      <p>Feature completes repair facility services import domestic cars, performing auto repair & service from brake state inspections.</p>
                      <a href="blog-details.html" class="btn btn-border sm c1-hover"><span>Read More</span> <img src="http://127.0.0.1:5173/assets/img/icon/plus-white.svg" alt="" class="svg"></a>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <section class="pt-120 pb-90">
       <div class="container">
          <div class="row justify-content-center">
             <div class="col-auto">
                <div class="section-title text-center">
                   <h5 class="top-title icon-center">Notension team</h5>
                   <h2>Professional Mechanic</h2>
                </div>
             </div>
          </div>
          <div class="row justify-content-center">
             <div class="col-lg-3 col-sm-6">
                <div class="single-team">
                   <div class="team-img"><img src="http://127.0.0.1:5173/assets/img/media/tm1.png" alt=""></div>
                   <div class="team-content">
                      <h3>Junaid Akhtar</h3>
                      <p>Computer Specialist</p>
                   </div>
                   <div class="team-social">
                      <div class="socials"><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i> </a>
                        <a href="https://www.twitter.com/" target="_blank"><i class="fab fa-twitter"></i> </a>
                        <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a></div>
                   </div>
                </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                <div class="single-team">
                   <div class="team-img"><img src="http://127.0.0.1:5173/assets/img/media/tm2.png" alt=""></div>
                   <div class="team-content">
                      <h3>Faheem Iqbal</h3>
                      <p>Techenical Specialist</p>
                   </div>
                   <div class="team-social">
                      <div class="socials"><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i> </a>
                        <a href="https://www.twitter.com/" target="_blank"><i class="fab fa-twitter"></i> </a>
                        <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a></div>
                   </div>
                </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                <div class="single-team">
                   <div class="team-img"><img src="http://127.0.0.1:5173/assets/img/media/tm3.png" alt=""></div>
                   <div class="team-content">
                      <h3>Raheem Khan</h3>
                      <p>Plumber Specialist</p>
                   </div>
                   <div class="team-social">
                      <div class="socials"><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i> </a>
                        <a href="https://www.twitter.com/" target="_blank"><i class="fab fa-twitter"></i> </a>
                        <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a></div>
                   </div>
                </div>
             </div>
             <div class="col-lg-3 col-sm-6">
                <div class="single-team">
                   <div class="team-img"><img src="http://127.0.0.1:5173/assets/img/media/tm4.png" alt=""></div>
                   <div class="team-content">
                      <h3>Usman Tahir</h3>
                      <p>Car Specialist</p>
                   </div>
                   <div class="team-social">
                      <div class="socials"><a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i> </a>
                        <a href="https://www.twitter.com/" target="_blank"><i class="fab fa-twitter"></i> </a>
                        <a href="https://www.instagram.com/" target="_blank"><i class="fab fa-instagram"></i></a></div>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <section class="pt-120 pb-120 video-section style--two bg-img" :style="{ backgroundImage: 'url(' + videoBg + ')' }">
       <div class="container">
          <div class="row justify-content-end">
             <div class="col-xl-6 col-lg-8 d-flex justify-content-center justify-content-lg-start">
                <div class="video-slider-wrap blue-bg">
                   <div class="video-slider swiper-container">
                      <div class="swiper-wrapper">
                         <div class="swiper-slide">
                            <div class="video-slide-card all-white">
                               <img src="http://127.0.0.1:5173/assets/img/icon/video-quote.svg" alt="" class="svg quote">
                               <p>I have been a seller on Notension from march. repair been very supportive & my sales are increased day delivery very fast mode of payments is very smooth to develop their business privacy policy.</p>
                               <div class="d-flex align-items-center">
                                  <div class="icon me-3"><img src="http://127.0.0.1:5173/assets/img/media/daniel.png" alt=""></div>
                                  <div class="content">
                                     <h3>Sana khan</h3>
                                     <p>Lovely Customer</p>
                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="swiper-slide">
                            <div class="video-slide-card all-white">
                               <img src="http://127.0.0.1:5173/assets/img/icon/video-quote.svg" alt="" class="svg quote">
                               <p>Global Electronic Services provides truly in-house comprehensive repair services and solutions for most manufacturers as well as new, refurbished and obsolete equipment. We have a 1-5 day standard</p>
                               <div class="d-flex align-items-center">
                                  <div class="icon me-3"><img src="http://127.0.0.1:5173/assets/img/media/daniel_01.png" alt=""></div>
                                  <div class="content">
                                     <h3>Jhon Wick</h3>
                                     <p>Lovely Customer</p>
                                  </div>
                               </div>
                            </div>
                         </div>
                         <div class="swiper-slide">
                            <div class="video-slide-card all-white">
                               <img src="http://127.0.0.1:5173/assets/img/icon/video-quote.svg" alt="" class="svg quote">
                               <p>I have been a seller on Notension from march. repair been very supportive & my sales are increased day delivery very fast mode of payments is very smooth to develop their business privacy policy.</p>
                               <div class="d-flex align-items-center">
                                  <div class="icon me-3"><img src="http://127.0.0.1:5173/assets/img/media/daniel_02.png" alt=""></div>
                                  <div class="content">
                                     <h3>Robert Downy</h3>
                                     <p>Lovely Customer</p>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                      <div class="swiper-pagination white"></div>
                   </div>
                </div>
             </div>
          </div>
       </div>
    </section>
    <div class="pt-120 pb-90">
       <div class="container">
          <div class="row justify-content-center">
             <div class="col-auto">
                <div class="section-title text-center">
                   <h5 class="top-title icon-center">Reserve Partner</h5>
                   <h2>Our Partners</h2>
                </div>
             </div>
          </div>
          <div class="row">
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/07.png" alt=""></div>
             </div>
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/08.png" alt=""></div>
             </div>
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/09.png" alt=""></div>
             </div>
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/10.png" alt=""></div>
             </div>
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/11.png" alt=""></div>
             </div>
             <div class="col-lg-2 col-sm-4 col-6">
                <div class="partner-logo text-center"><img src="http://127.0.0.1:5173/assets/img/partner/12.png" alt=""></div>
             </div>
          </div>
       </div>
    </div>
    
</template>

<script>
    import AboutBg from '/assets/img/bg/about-bg.png'
    import VideoBg from '/assets/img/bg/video-bg4.png'

    export default {
    data() {
        return {
            aboutBg: AboutBg,
            videoBg: VideoBg
        }
    }
    }
</script>
