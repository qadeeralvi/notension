<template>

<main class="pt-120 pb-120">
         <div class="container">
            <div class="row gutter-50">
               <div class="col-lg-8">
                  <div class="terms-content">
                     <div class="content">
                        <h3>Performance</h3>
                        <p>Developing these statements is especially important for any business in the seed phase. They will not only guide your have to decisions but also accelerate your growth. Creating these statements is not rocket science.</p>
                     </div>
                     <div class="content">
                        <h3>Payments</h3>
                        <p>Your mission statement helps your entire team know what it looks like to give your best each day. It focuses on the people you serve and reminds everyone that influence and success happen every day, not just in some rosy, far-off future. It should also help individuals tap into the intrinsic motivation that gives real meaning to their work.</p>
                     </div>
                     <div class="content">
                        <h3>Refund Policy</h3>
                        <p>These are generic service recommendations based solely on time or mileage not on visual appearance or measurement. their purpose is to extend the life of your vehicle and help prevent breakdown. Your vehicle’s requirements may differ depending on driving habits and/or owner’s manual recommendations. Check your owner’s manual and with your auto mechanic for specifics.</p>
                     </div>
                     <div class="content">
                        <h3>Prohibited Usage</h3>
                        <p>A list of prohibited content can be found below, which includes but not limited to the following:</p>
                        <ul class="list-unstyled ms-3">
                           <li>1. Virtual currency mining (such as bitcoin, prime coin etc.), except on plans with dedicated CPU</li>
                           <li>2. Child pornography</li>
                           <li>3. Malware/virus/security exploit activities</li>
                           <li>4. Terrorist activities</li>
                           <li>5. Port scanning, brute forcing or any other hacking attempts</li>
                           <li>6. Any car, disk or network abusing software. Including but not limited to card sharing exchange other similar software.</li>
                        </ul>
                     </div>
                     <div class="content">
                        <h3>Conclusion</h3>
                        <p>These are generic service recommendations based solely on time or mileage not on visual appearance or measurement. their purpose is to extend the life of your vehicle and help prevent breakdown. Your vehicle’s requirements may differ depending on driving habits and/or owner’s manual recommendations. Check your owner’s manual and with your auto mechanic for specifics.</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="terms-sidebar mt-60 mt-lg-0">
                     <div class="widget widget_service_hour white-dot all-white">
                        <h3 class="widget-title">Opening Hours</h3>
                        <div class="menu-container">
                           <ul class="menu">
                              <li><span>Monday </span>7.00 - 16.00</li>
                              <li><span>Tuesday</span>7.00 - 16.00</li>
                              <li><span>Wednesday</span>7.00 - 16.00</li>
                              <li><span>Thursday</span>7.00 - 16.00</li>
                              <li><span>Friday</span>7.00 - 16.00</li>
                              <li><span>Saturday</span>7.00 - 16.00</li>
                              <li><span>Sunday</span>7.00 - 16.00</li>
                           </ul>
                        </div>
                     </div>
                     <div class="testimonial-slider3 swiper-container">
                        <div class="swiper-wrapper">
                           <div class="swiper-slide">
                              <div class="d-flex align-items-center customer-top">
                                 <div class="img"><img :src="this.$main + 'assets/img/media/client8.png'" alt=""></div>
                                 <div class="meta">
                                    <h3>Kyra Knight</h3>
                                    <p>Happy Customer</p>
                                 </div>
                              </div>
                              <div class="rating"><img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-empty.svg'" alt="" class="svg"></div>
                              <p>Window repair generation repair space dedicated content over the each other when sensors indicate problemthey’re window service.</p>
                           </div>
                           <div class="swiper-slide">
                              <div class="d-flex align-items-center customer-top">
                                 <div class="img"><img :src="this.$main + 'assets/img/media/client9.png'" alt=""></div>
                                 <div class="meta">
                                    <h3>Rach McAdam</h3>
                                    <p>Happy Customer</p>
                                 </div>
                              </div>
                              <div class="rating"><img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"></div>
                              <p>Involve content generation constant space dedicat content over the each other when sensors indicate problemthey’re mobile service.</p>
                           </div>
                           <div class="swiper-slide">
                              <div class="d-flex align-items-center customer-top">
                                 <div class="img"><img :src="this.$main + 'assets/img/media/client10.png'" alt=""></div>
                                 <div class="meta">
                                    <h3>Olga Kurylen</h3>
                                    <p>Happy Customer</p>
                                 </div>
                              </div>
                              <div class="rating"><img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-fill.svg'" alt="" class="svg"> <img :src="this.$main + 'assets/img/icon/star-empty.svg'" alt="" class="svg"></div>
                              <p>New door Install service Notension space dedicate content over the each other when sensor indicate problemthey’re door service.</p>
                           </div>
                        </div>
                        <div class="swiper-pagination c_3"></div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </main>
      
</template>