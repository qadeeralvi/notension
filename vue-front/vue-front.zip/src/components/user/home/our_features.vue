<template>

        <section class="pt-60 ov-hidden">
			<div class="container">
				<div class="row align-items-center justify-content-between font-family-customer">
					<div class="col">
						<div class="section-title text-center style--four">
							<h5 class=" font-color">{{ this.translate('ourFeature') }}</h5>
							<h2>{{ this.translate('whyChoose') }}</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="feature-wrap ">
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f1.svg'" alt="" class="svg">
									<h3>{{ this.translate('nofix') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f2.svg'" alt="" class="svg">
									<h3>{{ this.translate('friendlyService') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f3.svg'" alt="" class="svg">
									<h3>{{ this.translate('wellReputation') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f4.svg'" alt="" class="svg">
									<h3>{{ this.translate('weProfessional') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f5.svg'" alt="" class="svg">
									<h3>{{ this.translate('support') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f6.svg'" alt="" class="svg">
									<h3>{{ this.translate('freeDiagnostic') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f7.svg'" alt="" class="svg">
									<h3>{{ this.translate('DayWarranted') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f8.svg'" alt="" class="svg">
									<h3>{{ this.translate('quickRepair') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f9.svg'" alt="" class="svg">
									<h3>{{ this.translate('lowPrice') }}</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img :src="this.$main + 'assets/img/icon/f10.svg'" alt="" class="svg">
									<h3>{{ this.translate('maxCovering') }}</h3>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
    
</template>