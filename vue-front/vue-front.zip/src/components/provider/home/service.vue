<template>

        <section class="pt-120 pb-120 bg-auto ovx-hidden" :style="{ backgroundImage: 'url(' + servicceBg + ')' }">
			<div class="container">
				<div class="row align-items-center justify-content-between">
					<div class="col-auto">
						<div class="section-title style--four all-white">
							<h5 class="top-title">Notension Service & Repair</h5>
							<h2>Services We Provide</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
					<div class="col-auto d-none d-lg-block">
						<div class="swiper-button-prev-unique three">
							<img src="assets/img/icon/nav-left.svg" alt="" class="svg">
						</div>
						<div class="swiper-button-next-unique three ms-2">
							<img src="assets/img/icon/nav-right.svg" alt="" class="svg">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="service-slider3 swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide"><img src="assets/img/media/service14.png" data-rjs="2" alt="">
									<div class="content">
										<div class="icon"><img src="assets/img/icon/service-content-icon.svg" class="svg" alt=""></div>
										<h3>Computer Repair</h3>
										<p>Inso content generation constant space dedicated content over the they’re computer service.</p><a href="service.html" class="btn btn-border c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
									</div>
								</div>
								<div class="swiper-slide"><img src="assets/img/media/service15.png" data-rjs="2" alt="">
									<div class="content">
										<div class="icon"><img src="assets/img/icon/service-content-icon2.svg" class="svg" alt=""></div>
										<h3>Laptop Repair</h3>
										<p>Inso content generation constant space dedicated content over the they’re computer service.</p><a href="service.html" class="btn btn-border c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
									</div>
								</div>
								<div class="swiper-slide"><img src="assets/img/media/service16.png" data-rjs="2" alt="">
									<div class="content">
										<div class="icon"><img src="assets/img/icon/service-content-icon3.svg" class="svg" alt=""></div>
										<h3>Tablet Repair</h3>
										<p>Inso content generation constant space dedicated content over the they’re computer service.</p><a href="service.html" class="btn btn-border c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row mt-50 pt-40">
					<div class="col-12">
						<div class="section-title style--four text-center">
							<h5 class="top-title">Our Pricing Plan</h5>
							<h2>Pricing Package</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="price-slider swiper-container">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="price">
										<div class="price-head">
											<h3>Desktop Repair</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 96 <span>(No Fix No Fees)</span></span>
										</div>
										<div class="price-body">
											<ul>
												<li><span>Display Repair</span> <span>$12</span></li>
												<li><span>Hardware Upgrade</span> <span>$34</span></li>
												<li><span>Software Installation</span> <span>$17</span></li>
												<li><span>SWindows Insllation</span> <span>$49</span></li>
												<li><span>Data Recovery</span> <span>$21</span></li>
												<li><span>Windows Activation</span> <span>$30</span></li>
											</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="price two">
										<div class="price-head">
											<h3>Laptop Repair</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 69 <span>(No Fix No Fees)</span></span>
										</div>
										<div class="price-body">
											<ul>
												<li><span>Display Repair</span> <span>$12</span></li>
												<li><span>Hardware Upgrade</span> <span>$34</span></li>
												<li><span>Software Installation</span> <span>$17</span></li>
												<li><span>SWindows Insllation</span> <span>$49</span></li>
												<li><span>Data Recovery</span> <span>$21</span></li>
												<li><span>Windows Activation</span> <span>$30</span></li>
											</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="price three">
										<div class="price-head">
											<h3>iPad/Tablet Repair</h3><span class="starting-at">Starting At…</span> <span class="price-text"><sup>$</sup> 36 <span>(No Fix No Fees)</span></span>
										</div>
										<div class="price-body">
											<ul>
												<li><span>Sound System Repair</span> <span>$50</span></li>
												<li><span>Display Repair</span> <span>$34</span></li>
												<li><span>Water Clean</span> <span>$35</span></li>
												<li><span>Camera Services</span> <span>$49</span></li>
												<li><span>Power Button Repair</span> <span>$25</span></li>
												<li><span>Headphone Repair</span> <span>$30</span></li>
											</ul><a href="price.html" class="btn c_5 btn-border"><span>Get start</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a>
										</div>
									</div>
								</div>
							</div>
							<div class="swiper-pagination c_5"></div>
						</div>
					</div>
				</div>
			</div>
		</section>
    
</template>

<script>
    import ServiceBg from '/assets/img/bg/service-bg4.png'

    export default {
    data() {
        return {
        servicceBg: ServiceBg
        }
    }
    }
</script>