<template>

        <section class="pt-120 pb-90 section-bg">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="section-title style--four text-center">
							<h5 class="top-title">Team Members</h5>
							<h2>Professional Mechanic</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
				</div>
				<div class="row justify-content-center">
					<div class="col-lg-4 col-sm-6">
						<div class="team style--two c_5"><img src="assets/img/media/team1.png" data-rjs="2" alt="">
							<div class="content">
								<h3>Jhon Wick</h3>
								<p>Top Mechanic</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="team style--two c_5 active"><img src="assets/img/media/team2.png" data-rjs="2" alt="">
							<div class="content">
								<h3>Michel Andarson</h3>
								<p>Top Mechanic</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="team style--two c_5"><img src="assets/img/media/team3.png" data-rjs="2" alt="">
							<div class="content">
								<h3>Robert Downy</h3>
								<p>Top Mechanic</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>

</template>