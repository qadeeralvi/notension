<template>

        <section class="pt-120 pb-90">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="section-title style--four text-center">
							<h5 class="top-title">Our Blog</h5>
							<h2>Latest News</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
				</div>
				<div class="row justify-content-center">
					<div class="col-lg-4 col-sm-6">
						<div class="single-post style--two c_5">
							<div class="post-thumb-wrap"><a href="blog-details.html" class="post-thumbnail"><img src="assets/img/post/post14.png" data-rjs="2" alt=""></a>
								<div class="posted-on c5-bg white"><a href="#" class="posted"><span class="day">23</span> AUG</a></div>
							</div>
							<div class="post-content"><a href="blog-details.html" class="post-tag c5">Tablets Repair</a> <a href="blog-details.html">
									<h3 class="post-title">How To Fix Mobiles Broken Smart Way to Dark</h3>
								</a><a href="blog-details.html" class="btn btn-border sm c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a></div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="single-post style--two c_5">
							<div class="post-thumb-wrap"><a href="blog-details.html" class="post-thumbnail"><img src="assets/img/post/post15.png" data-rjs="2" alt=""></a>
								<div class="posted-on c5-bg white"><a href="#" class="posted"><span class="day">24</span> AUG</a></div>
							</div>
							<div class="post-content"><a href="blog-details.html" class="post-tag c5">Mobiles Repair</a> <a href="blog-details.html">
									<h3 class="post-title">Mobile Button Power Button Fix Stream Running.</h3>
								</a><a href="blog-details.html" class="btn btn-border sm c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a></div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="single-post style--two c_5">
							<div class="post-thumb-wrap"><a href="blog-details.html" class="post-thumbnail"><img src="assets/img/post/post16.png" data-rjs="2" alt=""></a>
								<div class="posted-on c5-bg white"><a href="#" class="posted"><span class="day">26</span> AUG</a></div>
							</div>
							<div class="post-content"><a href="blog-details.html" class="post-tag c5">iMac/pc Repair</a> <a href="blog-details.html">
									<h3 class="post-title">How to Improve Our iMac Data Security Website.</h3>
								</a><a href="blog-details.html" class="btn btn-border sm c5-hover"><span>Read More</span> <img src="assets/img/icon/plus-white.svg" alt="" class="svg"></a></div>
						</div>
					</div>
				</div>
			</div>
		</section>

</template>