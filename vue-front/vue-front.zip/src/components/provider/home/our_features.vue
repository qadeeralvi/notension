<template>

        <section class="pt-120 pb-90 ov-hidden">
			<div class="container">
				<div class="row align-items-center justify-content-between">
					<div class="col">
						<div class="section-title text-center style--four">
							<h5 class="top-title">Our Features</h5>
							<h2>Why Choose Us</h2>
							<p>Involve content generation & consumption screen space dedicated content over other elements ensure they’re electronic service.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<div class="feature-wrap">
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f1.svg" alt="" class="svg">
									<h3>No Fix No Fees</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f2.svg" alt="" class="svg">
									<h3>Friendly Service</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f3.svg" alt="" class="svg">
									<h3>Well Reputation</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f4.svg" alt="" class="svg">
									<h3>We Are Professional</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f5.svg" alt="" class="svg">
									<h3>24/7 support</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f6.svg" alt="" class="svg">
									<h3>Free Diagnostic</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f7.svg" alt="" class="svg">
									<h3>7 Day Warranted</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f8.svg" alt="" class="svg">
									<h3>Quick Repair Process</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f9.svg" alt="" class="svg">
									<h3>Low Price Guaranteed</h3>
								</div>
							</div>
							<div class="hexagon hex-feature"><span></span>
								<div class="content"><img src="assets/img/icon/f10.svg" alt="" class="svg">
									<h3>Max Covering Areas</h3>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
    
</template>