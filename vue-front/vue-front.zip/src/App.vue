<template>
  <MainApp/>
</template>

<script>

  import MainApp from './views/Master.vue';

  export default {
      name: 'App',
      data() {
         
          return {
              
          };
      },
      created() {
      },
      components: {
          MainApp
      },
  }
</script>