
import Category from '../views/fronted/category.vue';
const routes = [
    {
        name:'Category',
        component: Category,
        path:"/category",
        meta:{title:'Category'},
    },
   
]

export default routes;  