
import Price from '../../views/provider/price.vue'
const routes = [
    {
        name:'Price',
        component: Price,
        path:"/provider/price",
        meta:{title:'Price'},
    },
    
]

export default routes;  