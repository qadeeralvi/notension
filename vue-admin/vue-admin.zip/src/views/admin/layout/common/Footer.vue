<template >
    <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6">
                              2022 © Notension
                            </div>
                            <div class="col-sm-6">
                                <div class="text-sm-right d-none d-sm-block">
                                    Design & Develop by  <a href="https://www.toppregnskap.no/">Shades Group of Technology</a>
                                </div>
                            </div>
                        </div>
                    </div>
    </footer>
        
</template>
