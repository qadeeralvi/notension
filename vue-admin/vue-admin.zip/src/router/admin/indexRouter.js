
import authRoute from './authRouter';

const routes = [
    ...authRoute
]



export default routes;  
